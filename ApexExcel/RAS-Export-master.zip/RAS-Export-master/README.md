RAS-Export
=================================

##About

Export Oracle RAS (Real Application Security) - Objects to sql-file

##Before Using

run grants.sql

##Requirements

APEX 5.0

##Current Stable Version

Version 1.00

##License

See LICENSE.md (MIT)
