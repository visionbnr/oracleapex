Sample Dashboard 2.
=================================

##About

This Dashboard demonstrates the possibilities of APEX in DB creation.

 $  An integration of ORACLE JET PictoChart component into Interacive Grid
 $  An integration of Map into Interactive Grid
 $  A integration of Pretius APEX nested report plugin into Interacive Grid
 $  Build-in Bar and Pie charts
 $  Using of SQL-Based List Element as a menu

The minimum required APEX-version is 5.1.3
Here's a link to a [demo](https://apex.oracle.com/pls/apex/f?p=DASHBOARD200) page.

##Current Version

Version 2.0


