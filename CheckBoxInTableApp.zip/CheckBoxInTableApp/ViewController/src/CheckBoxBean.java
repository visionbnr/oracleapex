import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCIteratorBinding;

import oracle.jbo.Row;
import oracle.jbo.ViewObject;

public class CheckBoxBean {
    public CheckBoxBean() {
    }
    public DCBindingContainer getDCBindingsContainer() {
        DCBindingContainer bindingsContainer =
            (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
        
        return bindingsContainer;
    }


    public void process(ActionEvent actionEvent) {
        DCBindingContainer bindings = this.getDCBindingsContainer();
        DCIteratorBinding itorBinding =
            bindings.findIteratorBinding("DepartmentsVO1Iterator");
        ViewObject vo = itorBinding.getViewObject();
        Row[]  selectedRolesRows =vo.getFilteredRows("SelectRow", true);
        
        for(Row row : selectedRolesRows){
            System.out.print("DepartmentId : "+row.getAttribute("DepartmentId"));
            System.out.println("Department Name : "+row.getAttribute("DepartmentName"));
        }
    }
}
