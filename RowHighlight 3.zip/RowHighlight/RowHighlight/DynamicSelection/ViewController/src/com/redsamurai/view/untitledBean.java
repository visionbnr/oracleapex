package com.redsamurai.view;

import javax.faces.event.ActionEvent;

import oracle.adf.model.BindingContext;

import oracle.binding.BindingContainer;
import oracle.binding.OperationBinding;

public class untitledBean {
    private String editStatus;
    private String usrrowStatus="test";
    public untitledBean() {
    }

    public String createButtonClick() {
        // Add event code here...
        setUsrrowStatus("NewRec"); 
        setEditStatus("userEdit");
        BindingContainer bindings = getBindings();
        OperationBinding operationBinding = bindings.getOperationBinding("CreateInsert");
        Object result = operationBinding.execute();
        if (!operationBinding.getErrors().isEmpty()) {
            return null;
        }
       
        return null;
    }
//    public BindingContainer getBindings() {
//        return BindingContext.getCurrent().getCurrentBindingsEntry();
//    }
    
    public String createButtonClick1() {
        BindingContainer bc = this.getBindings();
        oracle.adf.model.OperationBinding ob = (oracle.adf.model.OperationBinding)bc.getOperationBinding("getRowStatus");
        return (String)ob.execute();
    }
    public String getCreateEnabled() {
        BindingContainer bc = this.getBindings();
        oracle.adf.model.OperationBinding ob = (oracle.adf.model.OperationBinding)bc.getOperationBinding("getRowStatus");
        return (String)ob.execute();
    }

    public void editButtonClick(ActionEvent actionEvent) {
        // Add event code here...
        setEditStatus("userEdit");
    }

    public void saveButtonClick(ActionEvent actionEvent) {
        // Add event code here...
    }

    public void setEditStatus(String editStatus) {
        this.editStatus = editStatus;
    }

    public String getEditStatus() {
        return editStatus;
    }

    public void setUsrrowStatus(String usrrowStatus) {
        this.usrrowStatus = usrrowStatus;
    }

    public String getUsrrowStatus() {
        return usrrowStatus;
    }

    public BindingContainer getBindings() {
        return BindingContext.getCurrent().getCurrentBindingsEntry();
    }

    public String b6_action() {
        BindingContainer bindings = getBindings();
        OperationBinding operationBinding = bindings.getOperationBinding("CreateInsert1");
        Object result = operationBinding.execute();
        if (!operationBinding.getErrors().isEmpty()) {
            return null;
        }
        return null;
    }
}
