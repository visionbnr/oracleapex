package com.redsamurai.view.beans;

import oracle.adf.model.BindingContext;

import oracle.adf.model.OperationBinding;

import oracle.binding.BindingContainer;

public class Main {
    public BindingContainer getBindings() {
        return BindingContext.getCurrent().getCurrentBindingsEntry();
    }
    
    public String getCreateEnabled() {
        BindingContainer bc = this.getBindings();
        OperationBinding ob = (OperationBinding)bc.getOperationBinding("getRowStatus");
        return (String)ob.execute();
    }
}
