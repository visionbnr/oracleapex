package com.ras.demo.backing;


    import com.ras.demo.hr.HrAMImpl;

    import java.io.OutputStream;

    import java.text.SimpleDateFormat;

    import java.util.Date;

    import javax.el.ELContext;
    import javax.el.ExpressionFactory;
    import javax.el.ValueExpression;

    import javax.faces.application.Application;
    import javax.faces.context.FacesContext;

    import oracle.adf.view.rich.component.rich.input.RichInputText;
    import oracle.adf.view.rich.component.rich.nav.RichCommandButton;
    import oracle.adf.view.rich.component.rich.output.RichMessage;

    import oracle.apps.xdo.XDOException;

    import oracle.jbo.ApplicationModule;

    import org.apache.myfaces.trinidad.render.ExtendedRenderKitService;
    import org.apache.myfaces.trinidad.util.Service;

    public class hr {
        public hr() {
            super();
        }
        
        private RichCommandButton cb1;    
        private RichInputText it1;        
        private RichMessage m1;           
        
        

        public void setCb1(RichCommandButton cb1) {
            this.cb1 = cb1;
        }

        public RichCommandButton getCb1() {
            return cb1;
        }
       
        
        public void HrReport(FacesContext facesContext, OutputStream outputStream) throws XDOException{
                    
                    
            try{
                ApplicationModule am = this.getApplicationModuleForDataControl("HrAMDataControl");
                HrAMImpl amImpl = (HrAMImpl)am;
                       
                String deptId = (String)it1.getValue();   
                            
                //Method to be called here from applicationModuleImpl class
                byte[] result = amImpl.getHrReport(deptId);
                outputStream.write(result);  
                facesContext.responseComplete();
            }
            
            catch(Exception e){
                System.out.println(e.getMessage());
            }       
            
        }
        
        private boolean isInteger(String s) {
            try { 
                Integer.parseInt(s); 
            } catch(NumberFormatException e) { 
                return false; 
            }
           
            return true;
        }

        private static Object resolveExpression(String expression){
            FacesContext fctx = FacesContext.getCurrentInstance();
            Application app = fctx.getApplication();
            ExpressionFactory elFactory = app.getExpressionFactory();
            ELContext elContext = fctx.getELContext();
            
            ValueExpression elExpression = elFactory.createValueExpression(elContext, expression, Object.class);
            
            return elExpression.getValue(elContext);
            
        }   
       
        
        
        private static ApplicationModule getApplicationModuleForDataControl(String name){
            return (ApplicationModule)resolveExpression("#{data." + name + ".dataProvider}");
        }
        public void setIt1(RichInputText it1) {
            this.it1 = it1;
        }

        public RichInputText getIt1() {
            return it1;
        }

        public void setM1(RichMessage m1) {
            this.m1 = m1;
        }

        public RichMessage getM1() {
            return m1;
        }
        
        
        public String cb2_action() {
            
            // Add event code here...
            String p_deptId = (String)this.getIt1().getValue();    
            String str_p_deptId = "";
            
            boolean numeric = isInteger(p_deptId);
            
            if (numeric==false){
                this.getM1().setMessageType("error");
                this.getM1().setMessage("Please Enter Numeric");
                return null;
            }
            
            
            if(p_deptId != null && numeric==true){                               
             str_p_deptId = p_deptId.toString().trim(); 
            
             this.getM1().setMessageType("none");
             this.getM1().setMessage("");
             
             FacesContext fctx = FacesContext.getCurrentInstance();
             ExtendedRenderKitService etks = Service.getService(fctx.getRenderKit(), ExtendedRenderKitService.class);
             
             //id of generate report button
             String id = this.getCb1().getClientId();     //'id' used as param in customHandler javascript function in hr.jspx
                     
             etks.addScript(fctx, "customHandler('" + id + "');");

            }
            
            if(p_deptId==null || str_p_deptId .equals("")){
                this.getM1().setMessageType("error");
                this.getM1().setMessage("Please Enter Dept ID");
                
                return null;
                
            }
            
            
            return null;
        }
    }
