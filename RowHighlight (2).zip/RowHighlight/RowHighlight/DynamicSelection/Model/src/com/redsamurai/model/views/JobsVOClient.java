package com.redsamurai.model.views;

public class JobsVOClient {
    public JobsVOClient() {
        super();
    }
}
