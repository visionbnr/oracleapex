package com.redsamurai.view.beans;

import javax.el.ExpressionFactory;
import javax.el.ValueExpression;

import javax.faces.context.FacesContext;

import oracle.adf.model.BindingContext;

import oracle.adf.model.OperationBinding;

import oracle.adfinternal.view.faces.model.binding.FacesCtrlHierNodeBinding;

import oracle.binding.BindingContainer;

import oracle.jbo.Row;

public class Main {
    public BindingContainer getBindings() {
        return BindingContext.getCurrent().getCurrentBindingsEntry();
    }
    
    public String getCreateEnabled() {
        BindingContainer bc = this.getBindings();
        OperationBinding ob = (OperationBinding)bc.getOperationBinding("getRowStatus");
        return (String)ob.execute();
    }
    
    public String getCellColor() {
        FacesContext ctx = FacesContext.getCurrentInstance();
        ExpressionFactory ef = ctx.getApplication().getExpressionFactory();
        ValueExpression ve = ef.createValueExpression(ctx.getELContext(), "#{row}", FacesCtrlHierNodeBinding.class);
        
        FacesCtrlHierNodeBinding node = (FacesCtrlHierNodeBinding)ve.getValue(ctx.getELContext());
        Row row = node.getRow();
        
        BindingContainer bc = this.getBindings();
        OperationBinding ob = (OperationBinding)bc.getOperationBinding("getRowStatusColor");
        ob.getParamsMap().put("row", row);
        String status = (String)ob.execute();
        
        if (status.equals("Modified")) {
            return "background-color:Red;";
        }
        
        return null;
    }
}
