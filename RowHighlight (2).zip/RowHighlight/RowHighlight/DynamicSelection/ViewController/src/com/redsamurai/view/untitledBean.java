package com.redsamurai.view;

import javax.faces.event.ActionEvent;

public class untitledBean {
    private String editStatus;
    public untitledBean() {
    }

    public String createButtonClick() {
        // Add event code here...
        return null;
    }

    public void editButtonClick(ActionEvent actionEvent) {
        // Add event code here...
        setEditStatus("userEdit");
    }

    public void saveButtonClick(ActionEvent actionEvent) {
        // Add event code here...
    }

    public void setEditStatus(String editStatus) {
        this.editStatus = editStatus;
    }

    public String getEditStatus() {
        return editStatus;
    }
}
