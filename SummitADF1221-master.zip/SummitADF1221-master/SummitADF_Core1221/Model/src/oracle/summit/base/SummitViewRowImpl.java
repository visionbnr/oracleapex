package oracle.summit.base;

import oracle.jbo.server.ViewRowImpl;

public class SummitViewRowImpl extends ViewRowImpl {
  public SummitViewRowImpl() {
    super();
  }
}
