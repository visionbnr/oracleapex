package oracle.summit.base;

import oracle.jbo.server.ViewDefImpl;
import oracle.jbo.server.ViewObjectImpl;

public class SummitViewObjectImpl extends ViewObjectImpl {
  public SummitViewObjectImpl(String string, ViewDefImpl viewDefImpl) {
    super(string, viewDefImpl);
  }

  public SummitViewObjectImpl() {
    super();
  }
}
