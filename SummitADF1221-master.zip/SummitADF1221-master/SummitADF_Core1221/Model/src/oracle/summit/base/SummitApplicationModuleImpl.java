package oracle.summit.base;

import oracle.jbo.server.ApplicationModuleImpl;

public class SummitApplicationModuleImpl extends ApplicationModuleImpl {
  public SummitApplicationModuleImpl() {
    super();
  }
}
