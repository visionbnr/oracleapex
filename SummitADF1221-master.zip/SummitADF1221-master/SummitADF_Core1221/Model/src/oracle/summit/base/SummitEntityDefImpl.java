package oracle.summit.base;

import oracle.jbo.server.EntityDefImpl;

public class SummitEntityDefImpl extends EntityDefImpl {
    public SummitEntityDefImpl(int i, String string, String string1) {
        super(i, string, string1);
    }

    public SummitEntityDefImpl(String string) {
        super(string);
    }

    public SummitEntityDefImpl(int i, String string) {
        super(i, string);
    }

    public SummitEntityDefImpl() {
        super();
    }
}
