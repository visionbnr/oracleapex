package oracle.summit.model.polymorphicvo.views.common;

public interface SDeptViewSDO extends java.io.Serializable {

   public java.lang.Integer getId();

   public void setId(java.lang.Integer value);

   public java.lang.String getName();

   public void setName(java.lang.String value);

   public java.lang.Integer getRegionId();

   public void setRegionId(java.lang.Integer value);

   public java.util.List getSEmpView();

   public void setSEmpView(java.util.List value);


}

