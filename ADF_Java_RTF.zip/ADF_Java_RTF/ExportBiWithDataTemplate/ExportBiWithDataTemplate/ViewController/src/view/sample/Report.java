package view.sample;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import java.sql.Connection;

import javax.servlet.*;
import javax.servlet.http.*;

import oracle.apps.xdo.dataengine.DataProcessor;
import oracle.apps.xdo.template.FOProcessor;
import oracle.apps.xdo.template.RTFProcessor;

public class Report extends HttpServlet {
    private static final String CONTENT_TYPE = "application/pdf";

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType(CONTENT_TYPE);
       
        try
           {
                    javax.naming.Context initialContext = new javax.naming.InitialContext();
                    javax.sql.DataSource dataSource = 
                                        (javax.sql.DataSource)initialContext.lookup("jdbc/Conn");
                    Connection          connection = dataSource.getConnection();
                    DataProcessor dataProcessor = new DataProcessor();
                    dataProcessor.setDataTemplate("C:\\Users\\Unitask\\dataTemplate.xml");

                    dataProcessor.setConnection(connection);
                    dataProcessor.setDebugLogOn();
                    
                    dataProcessor.setTraceOn();
                    ByteArrayOutputStream out  = new ByteArrayOutputStream();
                    dataProcessor.setOutput(out);
                   // dataProcessor.setOutput("C:\\Users\\Unitask\\out.xml");
                    dataProcessor.processData();
                    
                    System.out.println("Done data template");
                    
                    byte[] data = out.toByteArray();
                    ByteArrayInputStream istream = new ByteArrayInputStream(data);
                    
                    RTFProcessor rtf = new RTFProcessor("C:\\Users\\Unitask\\Doc1.rtf");
                   
                    ByteArrayOutputStream outXslFo  = new ByteArrayOutputStream();
                    
                    rtf.setOutput(outXslFo);
                    rtf.process();
                    
                    byte[] dataXslFo = outXslFo.toByteArray();
                    ByteArrayInputStream inXslFo = new ByteArrayInputStream(dataXslFo);
                    
                    FOProcessor processor = new FOProcessor();
                
                    processor.setData(istream);
                    processor.setTemplate(inXslFo);
                    //processor.setOutput("C:\\Users\\Unitask\\catalog.ppt");
                    processor.setOutput(response.getOutputStream());
                    processor.setOutputFormat(FOProcessor.FORMAT_PDF);

                    processor.generate();
                    System.out.println("Done power point");
                    response.setContentType("text/plain");
                    response.getOutputStream().write("#toolbar=0&navpanes=0".getBytes());
                    response.getOutputStream().flush();            
                 }
                catch(Exception e)
                {
                        System.out.println(e.getMessage());
                        e.printStackTrace();
                }
    }
}
